        <div class="container contato_cont">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="row">
                        <div class="line d-md-none"></div>
                    </div>
                    <div class="row">
                        <h1 class="titulo w-100 text-center">Entre em contato conosco</h1>
                    </div>
                    <div class="row">
                        <div class="line d-md-none"></div>
                    </div>
                    <form class="form-horizontal">
                        <div class="row">
                            <label class="inpum">
                                <!--Nome completo:-->
                                <input type="text" name="Completo" class="form-control" value="" placeholder="Nome Completo:"/>
                            </label>
                        </div>
                        <div class="row">
                            <label class="inpdois">
                                <!--E-Mail-->
                                <input type="text" name="E-mail" class="form-control" value="" placeholder="E-Mail"/>
                            </label>
                        </div>
                        <div class="row">
                            <div class="line d-md-none"></div>
                        </div>
                        <div>
                            <h2 class="subtitulo w-100 text-center">Deixe sua Mensagem</h2>
                        </div>
                        <div class="row">
                            <div class="line d-md-none"></div>
                        </div>
                        <div class="row">
                            <label class="inpum">
                                <!--Area de Texto-->
                                <textarea class="form-control" placeholder="Mensagem"></textarea>
                            </label>
                        </div>
                        <div class="row">
                            <label class="m-auto">
                                <input class="send btn btn-danger" type="submit" value="Enviar"> 
                            </label>
                        </div>
                    </form> 
                </div>
                <div class="d-none d-sm-block col-md-6">
                    
                </div>
            </div>
        </div>
